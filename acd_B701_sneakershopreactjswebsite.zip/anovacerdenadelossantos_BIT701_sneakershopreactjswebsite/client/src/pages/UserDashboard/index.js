import MainLayout from './MainLayout';
import UserProfile from './UserProfile';
import UserShipping from './UserShipping';
import PurchaseHistory from './PurchaseHistory';

export { MainLayout, UserProfile, UserShipping, PurchaseHistory };
